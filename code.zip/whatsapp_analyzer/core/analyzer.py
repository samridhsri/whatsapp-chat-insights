"""
Core analysis functionality for WhatsApp chat data.

This module provides comprehensive analysis capabilities for parsed WhatsApp chat data,
including statistics, patterns, and insights.
"""

import logging
from collections import Counter
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px

from .parser import parse_chat

logger = logging.getLogger(__name__)


class ChatAnalyzer:
    """
    Main analyzer class for WhatsApp chat data.
    
    Provides comprehensive analysis capabilities including statistics,
    patterns, and visualization methods.
    """
    
    def __init__(self, chat_data: pd.DataFrame):
        """
        Initialize analyzer with parsed chat data.
        
        Args:
            chat_data: Parsed chat DataFrame from parse_chat()
        """
        self.chat_data = chat_data.copy()
        self._validate_data()
        self._prepare_data()
        
    def _validate_data(self) -> None:
        """Validate that required columns exist in chat data."""
        required_columns = ["Date", "Time", "Author", "Message", "ts", "date", "hour", "dow"]
        missing_columns = [col for col in required_columns if col not in self.chat_data.columns]
        
        if missing_columns:
            raise ValueError(f"Missing required columns: {missing_columns}")
    
    def _prepare_data(self) -> None:
        """Prepare data for analysis by adding derived fields."""
        # Add word count
        self.chat_data['word_count'] = self.chat_data['Message'].apply(
            lambda s: len(str(s).split()) if pd.notna(s) else 0
        )
        
        # Add character count
        self.chat_data['char_count'] = self.chat_data['Message'].apply(
            lambda s: len(str(s)) if pd.notna(s) else 0
        )
        
        # Sort by timestamp for time-based analysis
        self.chat_data = self.chat_data.sort_values('ts').reset_index(drop=True)
        
        logger.info(f"Prepared data with {len(self.chat_data)} messages")
    
    def get_basic_stats(self) -> Dict[str, Any]:
        """
        Get basic statistics about the chat.
        
        Returns:
            Dictionary containing basic statistics
        """
        stats = {
            "total_messages": len(self.chat_data),
            "total_participants": self.chat_data["Author"].nunique(),
            "days_active": self.chat_data["date"].nunique(),
            "date_range": {
                "start": self.chat_data["ts"].min().date().isoformat(),
                "end": self.chat_data["ts"].max().date().isoformat()
            },
            "total_words": int(self.chat_data["word_count"].sum()),
            "total_characters": int(self.chat_data["char_count"].sum()),
            "media_messages": int(self.chat_data["is_media"].sum()),
            "text_messages": int((~self.chat_data["is_media"]).sum())
        }
        
        # Add average message lengths
        text_only = self.chat_data[~self.chat_data["is_media"]]
        if not text_only.empty:
            stats["avg_words_per_message"] = round(text_only["word_count"].mean(), 1)
            stats["avg_chars_per_message"] = round(text_only["char_count"].mean(), 1)
        else:
            stats["avg_words_per_message"] = 0
            stats["avg_chars_per_message"] = 0
        
        return stats
    
    def get_participant_stats(self) -> pd.DataFrame:
        """
        Get statistics for each participant.
        
        Returns:
            DataFrame with participant statistics
        """
        participant_stats = self.chat_data.groupby("Author").agg({
            "Message": "count",
            "word_count": "sum",
            "char_count": "sum",
            "is_media": "sum",
            "ts": ["min", "max"]
        }).round(2)
        
        # Flatten column names
        participant_stats.columns = [
            "message_count", "total_words", "total_chars", 
            "media_count", "first_message", "last_message"
        ]
        
        # Calculate averages
        participant_stats["avg_words_per_message"] = (
            participant_stats["total_words"] / participant_stats["message_count"]
        ).round(1)
        
        participant_stats["avg_chars_per_message"] = (
            participant_stats["total_chars"] / participant_stats["message_count"]
        ).round(1)
        
        # Calculate activity period
        participant_stats["activity_days"] = (
            participant_stats["last_message"] - participant_stats["first_message"]
        ).dt.days
        
        # Sort by message count
        participant_stats = participant_stats.sort_values("message_count", ascending=False)
        
        return participant_stats
    
    def get_hourly_activity(self) -> pd.Series:
        """
        Get message activity by hour of day.
        
        Returns:
            Series with hour as index and message count as values
        """
        return self.chat_data.groupby("hour").size()
    
    def get_daily_activity(self) -> pd.Series:
        """
        Get message activity by day of week.
        
        Returns:
            Series with day of week as index and message count as values
        """
        day_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        daily_counts = self.chat_data.groupby("dow").size()
        return daily_counts.reindex(day_order, fill_value=0)
    
    def get_date_activity(self) -> pd.Series:
        """
        Get message activity by date.
        
        Returns:
            Series with date as index and message count as values
        """
        return self.chat_data.groupby("date").size()
    
    def get_response_times(self, threshold_hours: int = 1) -> pd.Series:
        """
        Calculate average response times for each participant.
        
        Args:
            threshold_hours: Hours of inactivity to consider as new conversation
            
        Returns:
            Series with participant as index and average response time in seconds
        """
        # Calculate time differences between consecutive messages
        time_diffs = self.chat_data['ts'].diff()
        
        # Identify responses (different author from previous message)
        is_response = self.chat_data['Author'] != self.chat_data['Author'].shift(1)
        
        # Filter responses within threshold
        threshold_timedelta = timedelta(hours=threshold_hours)
        valid_responses = (time_diffs <= threshold_timedelta) & is_response
        
        # Calculate response times
        response_times = time_diffs[valid_responses].dt.total_seconds()
        response_authors = self.chat_data[valid_responses]['Author']
        
        # Group by author and calculate mean
        avg_response_times = pd.Series(response_times.values, index=response_authors).groupby(level=0).mean()
        
        return avg_response_times.sort_values()
    
    def get_conversation_starters(self, threshold_hours: int = 1) -> pd.Series:
        """
        Count conversation starters for each participant.
        
        Args:
            threshold_hours: Hours of inactivity to consider as new conversation
            
        Returns:
            Series with participant as index and conversation starter count as values
        """
        threshold_timedelta = timedelta(hours=threshold_hours)
        time_diffs = self.chat_data['ts'].diff()
        
        # Message is a starter if time diff > threshold
        is_starter = time_diffs > threshold_timedelta
        
        # Count starters by author
        starter_counts = self.chat_data[is_starter]['Author'].value_counts()
        
        return starter_counts
    
    def get_emoji_analysis(self, emoji_extractor_func) -> Dict[str, Any]:
        """
        Analyze emoji usage in the chat.
        
        Args:
            emoji_extractor_func: Function to extract emojis from text
            
        Returns:
            Dictionary containing emoji analysis
        """
        emojis = []
        emoji_by_author = {}
        
        for _, row in self.chat_data.iterrows():
            if pd.notna(row["Message"]) and not row["is_media"]:
                message_emojis = emoji_extractor_func(row["Message"])
                emojis.extend(message_emojis)
                
                # Track emojis by author
                if row["Author"] not in emoji_by_author:
                    emoji_by_author[row["Author"]] = []
                emoji_by_author[row["Author"]].extend(message_emojis)
        
        if not emojis:
            return {
                "total_emojis": 0,
                "unique_emojis": 0,
                "top_emojis": [],
                "emoji_by_author": {}
            }
        
        # Overall emoji stats
        emoji_counter = Counter(emojis)
        total_emojis = len(emojis)
        unique_emojis = len(emoji_counter)
        top_emojis = emoji_counter.most_common(20)
        
        # Emojis by author
        author_emoji_counts = {
            author: Counter(author_emojis) 
            for author, author_emojis in emoji_by_author.items()
        }
        
        return {
            "total_emojis": total_emojis,
            "unique_emojis": unique_emojis,
            "top_emojis": top_emojis,
            "emoji_by_author": author_emoji_counts
        }
    
    def get_word_analysis(self, stop_words: Optional[List[str]] = None) -> Dict[str, Any]:
        """
        Analyze word usage in the chat.
        
        Args:
            stop_words: List of words to exclude from analysis
            
        Returns:
            Dictionary containing word analysis
        """
        if stop_words is None:
            stop_words = []
        
        words = []
        word_by_author = {}
        
        for _, row in self.chat_data.iterrows():
            if pd.notna(row["Message"]) and not row["is_media"]:
                message_words = [
                    word.lower().strip(".,!?\"':;()[]{}") 
                    for word in str(row["Message"]).split()
                    if word.lower().strip(".,!?\"':;()[]{}") not in stop_words
                ]
                words.extend(message_words)
                
                # Track words by author
                if row["Author"] not in word_by_author:
                    word_by_author[row["Author"]] = []
                word_by_author[row["Author"]].extend(message_words)
        
        if not words:
            return {
                "total_words": 0,
                "unique_words": 0,
                "top_words": [],
                "word_by_author": {}
            }
        
        # Overall word stats
        word_counter = Counter(words)
        total_words = len(words)
        unique_words = len(word_counter)
        top_words = word_counter.most_common(50)
        
        # Words by author
        author_word_counts = {
            author: Counter(author_words) 
            for author, author_words in word_by_author.items()
        }
        
        return {
            "total_words": total_words,
            "unique_words": unique_words,
            "top_words": top_words,
            "word_by_author": author_word_counts
        }
    
    def create_hourly_activity_chart(self) -> go.Figure:
        """Create hourly activity chart using Plotly."""
        hourly_data = self.get_hourly_activity()
        
        fig = go.Figure(data=[
            go.Bar(
                x=hourly_data.index,
                y=hourly_data.values,
                marker_color='lightblue',
                name='Messages'
            )
        ])
        
        fig.update_layout(
            title="Message Activity by Hour of Day",
            xaxis_title="Hour",
            yaxis_title="Number of Messages",
            xaxis=dict(tickmode='linear', tick0=0, dtick=1),
            showlegend=False
        )
        
        return fig
    
    def create_daily_activity_chart(self) -> go.Figure:
        """Create daily activity chart using Plotly."""
        daily_data = self.get_daily_activity()
        
        fig = go.Figure(data=[
            go.Bar(
                x=daily_data.index,
                y=daily_data.values,
                marker_color='lightgreen',
                name='Messages'
            )
        ])
        
        fig.update_layout(
            title="Message Activity by Day of Week",
            xaxis_title="Day of Week",
            yaxis_title="Number of Messages",
            showlegend=False
        )
        
        return fig
    
    def create_participant_activity_chart(self, top_n: int = 10) -> go.Figure:
        """Create participant activity chart using Plotly."""
        participant_stats = self.get_participant_stats()
        top_participants = participant_stats.head(top_n)
        
        fig = go.Figure(data=[
            go.Bar(
                x=top_participants.index,
                y=top_participants["message_count"],
                marker_color='lightcoral',
                name='Messages'
            )
        ])
        
        fig.update_layout(
            title=f"Top {top_n} Most Active Participants",
            xaxis_title="Participant",
            yaxis_title="Number of Messages",
            showlegend=False
        )
        
        return fig
    
    def create_conversation_starters_chart(self, threshold_hours: int = 1) -> go.Figure:
        """Create conversation starters chart using Plotly."""
        starter_counts = self.get_conversation_starters(threshold_hours)
        
        fig = go.Figure(data=[
            go.Pie(
                labels=starter_counts.index,
                values=starter_counts.values,
                hole=0.4,
                textinfo='percent',
                insidetextorientation='radial'
            )
        ])
        
        fig.update_layout(
            title=f"Conversation Starters (>{threshold_hours}h gap)",
            showlegend=True
        )
        
        return fig
    
    def export_analysis_report(self, output_path: str) -> None:
        """
        Export comprehensive analysis report to CSV.
        
        Args:
            output_path: Path to save the report
        """
        # Basic stats
        basic_stats = self.get_basic_stats()
        
        # Participant stats
        participant_stats = self.get_participant_stats()
        
        # Hourly and daily activity
        hourly_activity = self.get_hourly_activity()
        daily_activity = self.get_daily_activity()
        
        # Response times
        response_times = self.get_response_times()
        
        # Conversation starters
        conversation_starters = self.get_conversation_starters()
        
        # Create summary DataFrame
        summary_data = {
            "Metric": [
                "Total Messages", "Total Participants", "Days Active",
                "Total Words", "Total Characters", "Media Messages",
                "Text Messages", "Avg Words per Message", "Avg Chars per Message"
            ],
            "Value": [
                basic_stats["total_messages"],
                basic_stats["total_participants"],
                basic_stats["days_active"],
                basic_stats["total_words"],
                basic_stats["total_characters"],
                basic_stats["media_messages"],
                basic_stats["text_messages"],
                basic_stats["avg_words_per_message"],
                basic_stats["avg_chars_per_message"]
            ]
        }
        
        summary_df = pd.DataFrame(summary_data)
        
        # Export to Excel with multiple sheets
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            summary_df.to_excel(writer, sheet_name='Summary', index=False)
            participant_stats.to_excel(writer, sheet_name='Participant Stats')
            hourly_activity.to_frame('Message Count').to_excel(writer, sheet_name='Hourly Activity')
            daily_activity.to_frame('Message Count').to_excel(writer, sheet_name='Daily Activity')
            response_times.to_frame('Avg Response Time (seconds)').to_excel(writer, sheet_name='Response Times')
            conversation_starters.to_frame('Conversation Starters').to_excel(writer, sheet_name='Conversation Starters')
        
        logger.info(f"Analysis report exported to {output_path}")
    
    def get_all_insights(self) -> Dict[str, Any]:
        """
        Get all analysis insights in a single dictionary.
        
        Returns:
            Dictionary containing all analysis results
        """
        return {
            "basic_stats": self.get_basic_stats(),
            "participant_stats": self.get_participant_stats().to_dict(),
            "hourly_activity": self.get_hourly_activity().to_dict(),
            "daily_activity": self.get_daily_activity().to_dict(),
            "date_activity": self.get_date_activity().to_dict(),
            "response_times": self.get_response_times().to_dict(),
            "conversation_starters": self.get_conversation_starters().to_dict()
        } 